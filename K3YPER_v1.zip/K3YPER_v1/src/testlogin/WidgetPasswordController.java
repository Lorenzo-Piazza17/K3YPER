/*
 * Copyright (c) 2025 Lorenzo Piazza and Azan Khan
 * License: View only. Modification and redistribution prohibited.
 * Attribution to the authors is mandatory. See LICENSE.txt for details.
 * Contact: project.license.info@gmail.com
 */

package testlogin;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.ResourceBundle;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

import javax.crypto.SecretKey;

/**
 * Controller class for the password widget.
 * Handles editing, saving, deleting, and generating password entries.
 */
public class WidgetPasswordController implements Initializable {

    @FXML
    private TextField username; // Input field for the username
    @FXML
    private TextField email; // Input field for the email
    @FXML
    private TextField password; // Input field for the password
    @FXML
    private PasswordField passwordField; //PasswordField above the normal txt Field of the password
    @FXML
    private TextField link; // Input field for the link
    @FXML
    private TextArea note; // Input field for additional notes
    @FXML
    private Button saveButton; // Button to save changes
    @FXML
    private Button closeButton; // Button to close the widget
    @FXML
    private Button deleteButton; // Button to delete the password entry
    @FXML
    private Hyperlink generatePasswordLink; // Link to generate a random password
    @FXML
    private SplitPane splitPane; // SplitPane for layout
    @FXML
    private Label name; // Label for displaying the name with typing effect
    @FXML
    private CheckBox checkButton; //CheckBox to show or hide the passwordField

    private Timeline timeline; // Timeline for the typing effect
    private int charIndex = 0; // Index for the typing effect
    private String pName; // Name for the typing effect

    private Rectangle rectangle; // Background overlay for the widget
    private String userDataFileName; // File name for user data
    private int currentLineIndex; // Index of the entry being edited
    private SecretKey encryptionKey; // Encryption key for the session
    private HomeController homeController; // Reference to the HomeController
    private boolean isNewEntry = false; // Flag to indicate if this is a new entry

    /**
     * Initializes the controller class.
     * Sets up button actions and starts the typing effect.
     *
     * @param url The location used to resolve relative paths for the root object, or null if not known.
     * @param rb The resources used to localize the root object, or null if not available.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        saveButton.setOnAction(event -> saveChanges());
        if (deleteButton != null) {
            deleteButton.setOnAction(event -> deleteEntry());
        }
        if (generatePasswordLink != null) {
            generatePasswordLink.setOnAction(event -> generateRandomPassword());
        }
    }

    /**
     * Sets the background overlay for the widget.
     *
     * @param rectangle The Rectangle to set.
     */
    public void setRectangle(Rectangle rectangle) {
        this.rectangle = rectangle;
    }

    /**
     * Initializes the widget with data for editing or creating a new entry.
     *
     * @param decryptedPasswordData The decrypted password data, or null for a new entry.
     * @param lineIndex The index of the entry in the file.
     * @param dataFileName The user's data file name.
     * @param key The encryption key for the session.
     * @param hc The HomeController reference.
     */
    public void initData(String decryptedPasswordData, int lineIndex, String dataFileName, SecretKey key, HomeController hc) {
        this.userDataFileName = dataFileName;
        this.currentLineIndex = lineIndex;
        this.encryptionKey = key;
        this.homeController = hc;
        this.isNewEntry = (decryptedPasswordData == null);

        if (!isNewEntry) {
            String[] fields = decryptedPasswordData.split(",", 5);
            username.setText(fields.length > 0 ? fields[0] : "");
            email.setText(fields.length > 1 ? fields[1] : "");
            password.setText(fields.length > 2 ? fields[2] : "");
            passwordField.setText(fields.length > 2 ? fields[2] : "");;
            link.setText(fields.length > 3 ? fields[3] : "");
            pName = link.getText();
            note.setText(fields.length > 4 ? fields[4] : "");
        } else {
            username.clear();
            email.clear();
            password.clear();
            link.clear();
            note.clear();
            if (deleteButton != null) deleteButton.setDisable(true);
        }
        startTypingEffect();
    }

    /**
     * Starts a typing effect for the name label.
     * Gradually displays the text character by character.
     */
    private void startTypingEffect() {
        timeline = new Timeline(new KeyFrame(Duration.millis(60), event -> {
            if (charIndex < pName.length()) {
                name.setText(pName.substring(0, charIndex + 1));
                charIndex++;
            } else {
                timeline.stop();
            }
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    /**
     * Saves changes to the password entry.
     * Encrypts the data and calls the HomeController to update or add the entry.
     */
    private void saveChanges() {
        if (encryptionKey == null || homeController == null) {
            showAlert("Error", "Session Error", "Cannot save changes. Invalid session.");
            return;
        }

        String usernameValue = username.getText().replace(",", "");
        String emailValue = email.getText().replace(",", "");
        String passwordValue = password.getText().replace(",", "");
        String linkValue = link.getText().replace(",", "");
        String noteValue = note.getText().replace(",", "");

        String plainTextData = String.join(",", usernameValue, emailValue, passwordValue, linkValue, noteValue);

        if (isNewEntry) {
            homeController.addNewPasswordEntry(plainTextData);
        } else {
            homeController.updatePasswordEntry(currentLineIndex, plainTextData);
        }

        closeWidget();
    }

    /**
     * Deletes the current password entry.
     * Prompts the user for confirmation before deletion.
     */
    private void deleteEntry() {
        if (isNewEntry || homeController == null) {
            return;
        }

        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirm Deletion");
        alert.setHeaderText("Delete Password Entry");
        alert.setContentText("Are you sure you want to delete this password entry permanently?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            homeController.deletePasswordEntry(currentLineIndex);
            closeWidget();
        }
    }

    /**
     * Closes the widget window.
     * Hides the background overlay and closes the stage.
     */
    private void closeWidget() {
        if (rectangle != null) {
            rectangle.setVisible(false);
        }

        Stage stage = (Stage) saveButton.getScene().getWindow();
        if (stage != null) {
            homeController.setWidgetStageP();
            stage.close();
        }
    }

    /**
     * Shows an alert dialog with the specified title, header, and content.
     *
     * @param title The title of the alert.
     * @param header The header text of the alert.
     * @param content The content text of the alert.
     */
    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    /**
     * Generates a random 8-character password and sets it to the password field.
     */
    @FXML
    private void generateRandomPassword() {
        String upperCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lowerCase = "abcdefghijklmnopqrstuvwxyz";
        String numbers = "0123456789";
        String specialChars = "!@#$%^&*?";
        String allChars = upperCase + lowerCase + numbers + specialChars;

        Random random = new Random();
        StringBuilder passwordBuilder = new StringBuilder(8);

        passwordBuilder.append(upperCase.charAt(random.nextInt(upperCase.length())));
        passwordBuilder.append(lowerCase.charAt(random.nextInt(lowerCase.length())));
        passwordBuilder.append(numbers.charAt(random.nextInt(numbers.length())));
        passwordBuilder.append(specialChars.charAt(random.nextInt(specialChars.length())));

        for (int i = 4; i < 8; i++) {
            passwordBuilder.append(allChars.charAt(random.nextInt(allChars.length())));
        }

        String generatedPassword = shuffleString(passwordBuilder.toString());
        password.setText(generatedPassword);
    }

    /**
     * Shuffles the characters in a string.
     *
     * @param input The string to shuffle.
     * @return The shuffled string.
     */
    private String shuffleString(String input) {
        char[] characters = input.toCharArray();
        Random random = new Random();

        for (int i = 0; i < characters.length; i++) {
            int randomIndex = random.nextInt(characters.length);
            char temp = characters[i];
            characters[i] = characters[randomIndex];
            characters[randomIndex] = temp;
        }

        return new String(characters);
    }

    /**
     * This method is used by the checkButton to show and hide the passwordField and the password txt
     */
    @FXML
    private void ShowHidePassword() {
        if(checkButton.isSelected()){
            passwordField.setVisible(false);
            password.setVisible(true);
        }else{
            passwordField.setText(password.getText());
            passwordField.setVisible(true);
            password.setVisible(false);
        }

    }
}
