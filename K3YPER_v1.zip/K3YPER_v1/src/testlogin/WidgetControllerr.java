/*
 * Copyright (c) 2025 Lorenzo Piazza and Azan Khan
 * License: View only. Modification and redistribution prohibited.
 * Attribution to the authors is mandatory. See LICENSE.txt for details.
 * Contact: project.license.info@gmail.com
 */

package testlogin;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * Controller class for the password widget.
 * Handles the creation of new password entries, random password generation, and UI interactions.
 */
public class WidgetControllerr {

    @FXML
    private Button generateButton; // Button to generate a new password

    private FlowPane flowPane; // FlowPane to display password entries

    private Rectangle rectangle; // Background overlay for the widget

    private HomeController controller1; // Reference to the HomeController

    @FXML
    private TextField username; // Input field for the username
    @FXML
    private TextField email; // Input field for the email
    @FXML
    private TextField password; // Input field for the password
    @FXML
    private TextField link; // Input field for the link
    @FXML
    private TextField note; // Input field for additional notes
    @FXML
    private Hyperlink generatePasswordLink; // Link to trigger password generation
    @FXML
    private Label animatedLabel; // Label for displaying animated text

    private Timeline timeline; // Timeline for the typing effect
    private int charIndex = 0; // Index for the typing effect
    private String fullText = "Create a new password"; // Text for the typing effect

    /**
     * Sets user-specific context, primarily for reference if needed.
     *
     * @param username The current user's username.
     * @param dataFileName The user's data file name.
     */
    public void setUserData(String username, String dataFileName) {
        System.out.println("WidgetControllerr: User data set for " + username); // Optional: for debugging
    }

    /**
     * Sets the FlowPane for displaying password entries.
     *
     * @param flowPane The FlowPane to set.
     */
    public void setFlowPane(FlowPane flowPane) {
        this.flowPane = flowPane;
    }

    /**
     * Sets the background overlay for the widget.
     *
     * @param rectangle The Rectangle to set.
     */
    public void setRectangle(Rectangle rectangle) {
        this.rectangle = rectangle;
    }

    /**
     * Sets the reference to the HomeController.
     *
     * @param homeController The HomeController to set.
     */
    public void setController(HomeController homeController) {
        this.controller1 = homeController;
    }

    /**
     * Initializes the widget controller.
     * Sets up event handlers and starts the typing effect.
     */
    @FXML
    private void initialize() {
        if (generatePasswordLink != null) {
            generatePasswordLink.setOnAction(event -> generateRandomPassword());
        }
        if (generateButton != null) {
            generateButton.setOnAction(event -> createNewPasswordEntry());
        }
        startTypingEffect();
    }

    /**
     * Starts a typing effect for the animated label.
     * Gradually displays the text character by character.
     */
    private void startTypingEffect() {
        timeline = new Timeline(new KeyFrame(Duration.millis(60), event -> {
            if (charIndex < fullText.length()) {
                animatedLabel.setText(fullText.substring(0, charIndex + 1));
                charIndex++;
            } else {
                timeline.stop();
            }
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    /**
     * Generates a random 8-character password with uppercase, lowercase,
     * numbers, and special characters, then sets it to the password field.
     */
    @FXML
    private void generateRandomPassword() {
        String upperCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lowerCase = "abcdefghijklmnopqrstuvwxyz";
        String numbers = "0123456789";
        String specialChars = "!@#$%^&*?";
        String allChars = upperCase + lowerCase + numbers + specialChars;

        Random random = new Random();
        StringBuilder passwordBuilder = new StringBuilder(8);

        // Ensure at least one character from each category
        passwordBuilder.append(upperCase.charAt(random.nextInt(upperCase.length())));
        passwordBuilder.append(lowerCase.charAt(random.nextInt(lowerCase.length())));
        passwordBuilder.append(numbers.charAt(random.nextInt(numbers.length())));
        passwordBuilder.append(specialChars.charAt(random.nextInt(specialChars.length())));

        // Fill the rest of the password
        for (int i = 4; i < 8; i++) {
            passwordBuilder.append(allChars.charAt(random.nextInt(allChars.length())));
        }

        // Shuffle the password characters
        String generatedPassword = shuffleString(passwordBuilder.toString());

        // Set the password in the password field
        password.setText(generatedPassword);
    }

    /**
     * Shuffles the characters in a string.
     *
     * @param input The string to shuffle.
     * @return The shuffled string.
     */
    private String shuffleString(String input) {
        char[] characters = input.toCharArray();
        Random random = new Random();

        for (int i = 0; i < characters.length; i++) {
            int randomIndex = random.nextInt(characters.length);
            char temp = characters[i];
            characters[i] = characters[randomIndex];
            characters[randomIndex] = temp;
        }

        return new String(characters);
    }

    /**
     * Creates a new password entry and adds it to the FlowPane.
     * Clears the input fields and closes the widget after saving.
     */
    @FXML
    private void createNewPasswordEntry() {
        if (controller1 == null) {
            System.err.println("Error: HomeController reference not set in WidgetControllerr.");
            return;
        }

        String usernameValue = username.getText() != null ? username.getText().replace(",", "") : "";
        String emailValue = email.getText() != null ? email.getText().replace(",", "") : "";
        String passwordValue = password.getText() != null ? password.getText().replace(",", "") : "";
        String linkValue = link.getText() != null ? link.getText().replace(",", "") : "";
        String noteValue = note.getText() != null ? note.getText().replace(",", "") : "";

        String plainTextData = String.join(",", usernameValue, emailValue, passwordValue, linkValue, noteValue);

        controller1.addNewPasswordEntry(plainTextData);

        clearFields();

        if (rectangle != null) {
            rectangle.setVisible(false);
        }
        Stage stage = (Stage) generateButton.getScene().getWindow();
        if (stage != null) {
            controller1.setWidgetStage();
            stage.close();
        }
    }

    /**
     * Clears all input fields after saving.
     */
    private void clearFields() {
        username.clear();
        email.clear();
        password.clear();
        link.clear();
        note.clear();
    }

    /**
     * Helper method to show alerts.
     *
     * @param title The title of the alert.
     * @param header The header text of the alert.
     * @param content The content text of the alert.
     */
    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
