/*
 * Copyright (c) 2025 Lorenzo Piazza and Azan Khan
 * License: View only. Modification and redistribution prohibited.
 * Attribution to the authors is mandatory. See LICENSE.txt for details.
 * Contact: project.license.info@gmail.com
 */

package testlogin;

import javafx.scene.image.Image;

import javax.crypto.SecretKey;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * Utility class for user authentication and management.
 * Handles user registration, login, password hashing, and encryption key derivation.
 */
public class UserAuth {

    private static final String MAIN_CSV_FILE = "users.csv"; // File storing user data
    private static final String PERCORSO_PROGETTO = System.getProperty("user.dir");
    private static final String IMGBASE = ("file:\\" + PERCORSO_PROGETTO + "\\src\\assets\\base.png"); // Default profile image
    private static String currentLoggedInUserPassword; // Temporarily stores the password during the session

    /**
     * Temporarily stores the password of the currently logged-in user.
     *
     * @param password The password to store.
     */
    public static void setCurrentUserPassword(String password) {
        currentLoggedInUserPassword = password;
    }

    /**
     * Retrieves the temporarily stored password of the currently logged-in user.
     *
     * @return The stored password.
     */
    public static String getCurrentUserPassword() {
        return currentLoggedInUserPassword;
    }

    /**
     * Clears the temporarily stored password from memory.
     */
    public static void clearCurrentUserPassword() {
        currentLoggedInUserPassword = null;
    }

    /**
     * Represents a user with associated details such as username, password hash, salt, and profile image.
     */
    public static class User {
        private String username;
        private String passwordHash;
        private String salt;
        private String dataFileName;
        private String image;

        /**
         * Constructs a User object with the specified details.
         *
         * @param username The username of the user.
         * @param passwordHash The hashed password of the user.
         * @param salt The salt used for hashing the password.
         * @param image The profile image of the user.
         */
        public User(String username, String passwordHash, String salt, String image) {
            this.username = username;
            this.passwordHash = passwordHash;
            this.salt = salt;
            this.dataFileName = username + ".csv";
            this.image = image;
        }

        /**
         * Constructs a User object with the specified details, including a custom data file name.
         *
         * @param username The username of the user.
         * @param passwordHash The hashed password of the user.
         * @param salt The salt used for hashing the password.
         * @param image The profile image of the user.
         * @param dataFileName The custom data file name for the user.
         */
        public User(String username, String passwordHash, String salt, String image, String dataFileName) {
            this.username = username;
            this.passwordHash = passwordHash;
            this.salt = salt;
            this.dataFileName = dataFileName;
            this.image = image;
        }

        public String getUsername() {
            return username;
        }

        public String getPasswordHash() {
            return passwordHash;
        }

        public String getSalt() {
            return salt;
        }

        public String getDataFileName() {
            return dataFileName;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }
    }

    /**
     * Checks if a user with the specified username exists.
     *
     * @param username The username to check.
     * @return True if the user exists, false otherwise.
     */
    public static boolean userExists(String username) {
        List<User> users = getAllUsers();
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Generates a random salt for password hashing.
     *
     * @return A Base64 encoded salt string.
     */
    private static String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    /**
     * Hashes a password with the specified salt using SHA-256.
     *
     * @param password The password to hash.
     * @param salt The salt to use for hashing.
     * @return The hashed password as a Base64 encoded string.
     */
    private static String hashPassword(String password, String salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt.getBytes());
            byte[] hashedPassword = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hashedPassword);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Registers a new user with the specified username and password.
     *
     * @param username The username of the new user.
     * @param password The password of the new user.
     * @return True if registration is successful, false otherwise.
     */
    public static boolean registerUser(String username, String password) {
        if (userExists(username)) {
            return false;
        }

        try (FileWriter fw = new FileWriter(MAIN_CSV_FILE, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {

            String salt = generateSalt();
            String passwordHash = hashPassword(password, salt);

            out.println(username + "," + passwordHash + "," + salt + "," + IMGBASE + "," + username + ".csv");

            FileWriter userFileWriter = new FileWriter(username + ".csv");
            userFileWriter.close();

            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Authenticates a user with the specified username and password.
     *
     * @param username The username of the user.
     * @param password The password of the user.
     * @return True if authentication is successful, false otherwise.
     */
    public static boolean authenticateUser(String username, String password) {
        User user = getUser(username);
        if (user != null) {
            String hashedPassword = hashPassword(password, user.getSalt());
            if (hashedPassword != null && hashedPassword.equals(user.getPasswordHash())) {
                setCurrentUserPassword(password);
                return true;
            }
        }
        clearCurrentUserPassword();
        return false;
    }

    /**
     * Retrieves the data file name for the specified user.
     *
     * @param username The username of the user.
     * @return The data file name, or null if the user does not exist.
     */
    public static String getUserDataFileName(String username) {
        List<User> users = getAllUsers();
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user.getDataFileName();
            }
        }
        return null;
    }

    /**
     * Retrieves the profile image for the specified user.
     *
     * @param username The username of the user.
     * @return The profile image URL, or null if the user does not exist.
     */
    public static String getImmagine(String username) {
        List<User> users = getAllUsers();
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user.getImage();
            }
        }
        return null;
    }

    /**
     * Sets a new profile image for the specified user.
     *
     * @param username The username of the user.
     * @param image The new profile image URL.
     */
    public static void setImmagine(String username, String image) {
        List<User> users = getAllUsers();
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                user.setImage(image);
                uploadImage(image, username);
            }
        }
    }

    /**
     * Updates the profile image in the user data file.
     *
     * @param image The new profile image URL.
     * @param username The username of the user.
     */
    private static void uploadImage(String image, String username) {
        File file = new File(MAIN_CSV_FILE);
        List<String> lines = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(MAIN_CSV_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values[0].equals(username)) {
                    values[3] = image;
                }
                lines.add(String.join(",", values));
            }

            try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
                for (String modifiedLine : lines) {
                    bw.write(modifiedLine);
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Retrieves all users from the user data file.
     *
     * @return A list of all users.
     */
    private static List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        File file = new File(MAIN_CSV_FILE);

        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                return users;
            }
        }

        try (BufferedReader br = new BufferedReader(new FileReader(MAIN_CSV_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length >= 5) {
                    User user = new User(values[0], values[1], values[2], values[3], values[4]);
                    users.add(user);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return users;
    }

    /**
     * Derives an encryption key for the current user using their master password and salt.
     *
     * @param username The username of the user.
     * @return The derived encryption key, or null if derivation fails.
     */
    public static SecretKey deriveEncryptionKeyForCurrentUser(String username) {
        String masterPassword = getCurrentUserPassword();
        String base64Salt = getUserSalt(username);

        if (masterPassword == null || base64Salt == null) {
            System.err.println("Error: Cannot derive key. User not logged in or salt not found.");
            return null;
        }

        byte[] saltBytes = CryptoUtils.decodeSalt(base64Salt);
        if (saltBytes == null) {
            System.err.println("Error: Failed to decode salt for key derivation.");
            return null;
        }

        try {
            return CryptoUtils.deriveKey(masterPassword, saltBytes);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            System.err.println("Error deriving encryption key: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Retrieves a User object by username.
     *
     * @param username The username of the user.
     * @return The User object, or null if the user does not exist.
     */
    public static User getUser(String username) {
        List<User> users = getAllUsers();
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    /**
     * Retrieves the salt for the specified user.
     *
     * @param username The username of the user.
     * @return The Base64 encoded salt, or null if the user does not exist.
     */
    public static String getUserSalt(String username) {
        User user = getUser(username);
        return (user != null) ? user.getSalt() : null;
    }
}