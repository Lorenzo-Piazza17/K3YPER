/*
 * Copyright (c) 2025 Lorenzo Piazza and Azan Khan
 * License: View only. Modification and redistribution prohibited.
 * Attribution to the authors is mandatory. See LICENSE.txt for details.
 * Contact: project.license.info@gmail.com
 */

package testlogin;

import java.io.IOException;

import javafx.scene.image.Image;
import javafx.util.Duration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.PauseTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Main class for the application.
 * This class initializes the application, displays the splash screen, and transitions to the login screen.
 */
public class Main extends Application {

    /**
     * Entry point for the JavaFX application.
     * Displays the splash screen and transitions to the login screen after a delay.
     *
     * @param primaryStage The primary stage for the application.
     * @throws Exception If an error occurs while loading the FXML file.
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        // Load the splash screen (Start.fxml)
        Parent root = FXMLLoader.load(getClass().getResource("Start.fxml"));
        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("/assets/Senzanome.png")));
        primaryStage.setTitle("Start");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.setResizable(false);
        primaryStage.show();

        // Create a delay of 2 seconds before transitioning to the login screen
        PauseTransition delay = new PauseTransition(Duration.seconds(2));
        delay.setOnFinished(event -> {
            try {
                loadLogin(primaryStage, root);
            } catch (IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        // Start the delay
        delay.play();
    }

    /**
     * Transitions from the splash screen to the login screen with a sliding animation.
     *
     * @param primaryStage The primary stage of the application.
     * @param oldRoot The root node of the current scene (splash screen).
     * @throws IOException If an error occurs while loading the Login.fxml file.
     */
    public void loadLogin(Stage primaryStage, Parent oldRoot) throws IOException {
        // Load the login screen (Login.fxml)
        Parent newRoot = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Scene scene = primaryStage.getScene();

        // Position the new screen outside the stage (to the right)
        newRoot.translateXProperty().set(scene.getWidth());

        // Set the new root node for the scene
        scene.setRoot(newRoot);

        // Create an animation to slide the new screen into the center
        TranslateTransition slideIn = new TranslateTransition(Duration.seconds(0.5), newRoot);
        slideIn.setToX(0);

        // Create an animation to slide the old screen out to the left
        TranslateTransition slideOut = new TranslateTransition(Duration.seconds(0.5), oldRoot);
        slideOut.setToX(-scene.getWidth());

        // Play the slide-out animation first, then the slide-in animation
        slideOut.setOnFinished(event -> slideIn.play());
        primaryStage.setTitle("Login");
        slideOut.play();
    }

    /**
     * Main method for launching the application.
     *
     * @param args Command-line arguments.
     */
    public static void main(String[] args) {
        launch(args);
    }
}