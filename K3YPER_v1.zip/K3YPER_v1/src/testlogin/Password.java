/*
 * Copyright (c) 2025 Lorenzo Piazza and Azan Khan
 * License: View only. Modification and redistribution prohibited.
 * Attribution to the authors is mandatory. See LICENSE.txt for details.
 * Contact: project.license.info@gmail.com
 */

package testlogin;

/**
 * Represents a password entry with associated details such as username, email, link, and notes.
 * This class provides getter and setter methods to manage the password entry data.
 */
public class Password {
    private String username; // The username associated with the password
    private String email;    // The email associated with the password
    private String password; // The actual password
    private String link;     // The link or URL associated with the password
    private String note;     // Additional notes about the password entry

    /**
     * Constructs a new Password object with the specified details.
     *
     * @param username The username associated with the password.
     * @param email The email associated with the password.
     * @param password The actual password.
     * @param link The link or URL associated with the password.
     * @param note Additional notes about the password entry.
     */
    public Password(String username, String email, String password, String link, String note) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.link = link;
        this.note = note;
    }

    /**
     * Sets the username associated with the password.
     *
     * @param username The username to set.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Sets the email associated with the password.
     *
     * @param email The email to set.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Sets the actual password.
     *
     * @param password The password to set.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Sets the link or URL associated with the password.
     *
     * @param link The link to set.
     */
    public void setLink(String link) {
        this.link = link;
    }

    /**
     * Sets additional notes about the password entry.
     *
     * @param note The note to set.
     */
    public void setNote(String note) {
        this.note = note;
    }

    /**
     * Gets the username associated with the password.
     *
     * @return The username.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Gets the email associated with the password.
     *
     * @return The email.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Gets the actual password.
     *
     * @return The password.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Gets the link or URL associated with the password.
     *
     * @return The link.
     */
    public String getLink() {
        return link;
    }

    /**
     * Gets additional notes about the password entry.
     *
     * @return The notes.
     */
    public String getNote() {
        return note;
    }
}
