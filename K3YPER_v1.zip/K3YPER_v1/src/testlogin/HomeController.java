/*
 * Copyright (c) 2025 Lorenzo Piazza and Azan Khan
 * License: View only. Modification and redistribution prohibited.
 * Attribution to the authors is mandatory. See LICENSE.txt for details.
 * Contact: project.license.info@gmail.com
 */

package testlogin;

import java.io.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.*;
import java.util.ArrayList;
import java.util.List;
import javafx.geometry.Rectangle2D;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javax.crypto.SecretKey;
import static testlogin.UserAuth.getUserDataFileName;

/**
 * Controller class for the Home screen of the application.
 * Handles user interactions, password management, and UI updates.
 */
public class HomeController {

    // Variables for managing UI and user session
    private final double xOffset = 0;
    private final double yOffset = 0;
    private Stage widgetStage = new Stage(); // Widget for creating passwords
    private Stage widgetStageP = new Stage(); // Widget for password editing

    @FXML
    private ScrollPane scrollPane;

    @FXML
    private FlowPane flowpane;

    @FXML
    private StackPane stackPane;

    @FXML
    private Rectangle opaqueBackground; // Background overlay for widgets

    @FXML
    private Label welcomeLabel;

    @FXML
    private ImageView immagine;

    private String username;
    private String userDataFileName;
    private String img;

    private SecretKey encryptionKey; // Stores the derived encryption key for the session

    /**
     * Initializes the HomeController with user-specific data.
     * 
     * @param username The username of the logged-in user.
     */
    public void initData(String username) {
        this.username = username;
        this.userDataFileName = UserAuth.getUserDataFileName(username);
        this.img = UserAuth.getImmagine(username);

        // Derive the encryption key for the session
        this.encryptionKey = UserAuth.deriveEncryptionKeyForCurrentUser(username);

        if (this.encryptionKey == null) {
            System.err.println("FATAL: Could not derive encryption key for user " + username);
            showAlert("Error", "Encryption Key Error", "Could not prepare user session. Please log in again.");
            logout();
            return;
        }

        flowpane.setHgap(10); // Horizontal gap between password boxes
        flowpane.setVgap(10); // Vertical gap between password boxes

        // Load and set the user's profile image
        Image image = new Image(img);
        immagine.setImage(image);

        // Set up context menu for profile image
        ContextMenu contextMenu = new ContextMenu();
        MenuItem item1 = new MenuItem("Change Image");
        MenuItem item2 = new MenuItem("Logout");
        contextMenu.getItems().addAll(item1, item2);

        item1.setOnAction(e -> {
            changeImage();
        });

        item2.setOnAction(e -> {
            handleLogout(immagine);
        });

        immagine.setOnMouseClicked(e -> {
            if (e.getButton() == MouseButton.PRIMARY) {
                contextMenu.show(immagine, e.getScreenX(), e.getScreenY());
            }
        });

        // Load saved passwords
        loadSavedPasswords();
    }

    /**
     * Opens a file chooser to allow the user to change their profile image.
     */
    @FXML
    private void changeImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Upload PNG File");

        String projectPath = System.getProperty("user.dir");
        File defaultFolder = new File(projectPath, "/src/immagini");
        if (defaultFolder.exists() && defaultFolder.isDirectory()) {
            fileChooser.setInitialDirectory(defaultFolder);
        }

        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG Files (*.png)", "*.png"));

        File file = fileChooser.showOpenDialog(null);

        if (file != null) {
            Image image = new Image(file.toURI().toString());
            immagine.setImage(image);
            UserAuth.setImmagine(username, file.toURI().toString());
        }
    }

    /**
     * Starts the widget for creating new passwords.
     */
    @FXML
    private void startWidget() {
        try {
            opaqueBackground.setVisible(true);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Widget.fxml"));
            Parent root = loader.load();
            WidgetControllerr controller2 = loader.getController();
            controller2.setFlowPane(flowpane);
            controller2.setRectangle(opaqueBackground);
            controller2.setController(this);
            controller2.setUserData(this.username, this.userDataFileName);

            Scene scene = new Scene(root);
            scene.setFill(null);

            widgetStage.initStyle(StageStyle.UNDECORATED);
            widgetStage.setScene(scene);

            Stage mainStage = (Stage) stackPane.getScene().getWindow();
            double x = (mainStage.getWidth() - root.prefWidth(-1)) / 2;
            double y = (mainStage.getHeight() - root.prefHeight(-1)) / 2;

            widgetStage.setX(mainStage.getX() + x);
            widgetStage.setY(mainStage.getY() + y);

            widgetStage.show();

            mainStage.xProperty().addListener((obs, oldX, newX) ->
                widgetStage.setX(newX.doubleValue() + (mainStage.getWidth() - root.prefWidth(-1)) / 2)
            );
            mainStage.yProperty().addListener((obs, oldY, newY) ->
                widgetStage.setY(newY.doubleValue() + (mainStage.getHeight() - root.prefHeight(-1)) / 2)
            );

            mainStage.setOnCloseRequest(event -> {
                if (widgetStage != null && widgetStage.isShowing()) {
                    widgetStage.close();
                }
            });

            mainStage.iconifiedProperty().addListener((observable, wasMinimized, isNowMinimized) -> {
                if (isNowMinimized) {
                    widgetStage.setIconified(true);
                }
            });

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Closes the widget and hides the background overlay.
     */
    @FXML
    private void closeWidgetOnClick() {
        if (widgetStage != null) {
            widgetStage.close();
            widgetStage = new Stage();
            opaqueBackground.setVisible(false);
        }
        if (widgetStageP != null) {
            widgetStageP.close();
            widgetStageP = new Stage();
            opaqueBackground.setVisible(false);
        }
    }

    /**
     * Sets a new widget stage for password creation.
     */
    public void setWidgetStage() {
        widgetStage = new Stage();
    }

    /**
     * Sets a new widget stage for password editing.
     */
    public void setWidgetStageP() {
        widgetStageP = new Stage();
    }

    /**
     * Starts the widget for editing/viewing a password entry.
     * 
     * @param decryptedPasswordData The decrypted password data.
     * @param lineIndex The index of the password entry in the file.
     */
    public void startWidgetP(String decryptedPasswordData, int lineIndex) {
        try {
            opaqueBackground.setVisible(true);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("WidgetPassword.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            scene.setFill(null);

            WidgetPasswordController controller = loader.getController();
            controller.initData(decryptedPasswordData, lineIndex, userDataFileName, encryptionKey, this);
            controller.setRectangle(opaqueBackground);

            widgetStageP.initStyle(StageStyle.UNDECORATED);
            widgetStageP.setScene(scene);

            Stage mainStage = (Stage) stackPane.getScene().getWindow();
            double x = (mainStage.getWidth() - root.prefWidth(-1)) / 2;
            double y = (mainStage.getHeight() - root.prefHeight(-1)) / 2;

            widgetStageP.setX(mainStage.getX() + x);
            widgetStageP.setY(mainStage.getY() + y);

            widgetStageP.show();

            mainStage.xProperty().addListener((obs, oldX, newX) ->
                widgetStageP.setX(newX.doubleValue() + (mainStage.getWidth() - root.prefWidth(-1)) / 2)
            );
            mainStage.yProperty().addListener((obs, oldY, newY) ->
                widgetStageP.setY(newY.doubleValue() + (mainStage.getHeight() - root.prefHeight(-1)) / 2)
            );

            mainStage.setOnCloseRequest(event -> {
                if (widgetStageP != null && widgetStageP.isShowing()) {
                    widgetStageP.close();
                }
            });

            mainStage.iconifiedProperty().addListener((observable, wasMinimized, isNowMinimized) -> {
                if (isNowMinimized) {
                    widgetStageP.setIconified(true);
                }
            });

            loadSavedPasswords();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles user logout and redirects to the login screen.
     * 
     * @param sourceNode The source node triggering the logout.
     */
    private void handleLogout(Node sourceNode) {
        try {
            Parent loginRoot = FXMLLoader.load(getClass().getResource("Login.fxml"));
            Stage stage = (Stage) (sourceNode.getScene()).getWindow();
            stage.setScene(new Scene(loginRoot, 600, 400));

            Rectangle2D screenBounds = Screen.getPrimary().getBounds();
            double x = (screenBounds.getWidth() - stage.getWidth()) / 2;
            double y = (screenBounds.getHeight() - stage.getHeight()) / 2;

            stage.setX(x);
            stage.setY(y);
            stage.setTitle("Login");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Logs out the user and clears the session.
     */
    @FXML
    private void logout() {
        UserAuth.clearCurrentUserPassword();
        try {
            Stage stage = (Stage) flowpane.getScene().getWindow();
            Parent loginRoot = FXMLLoader.load(getClass().getResource("Login.fxml"));
            Scene scene = new Scene(loginRoot);
            stage.setScene(scene);
            stage.setTitle("Login");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Logout Failed", "Could not return to the login screen.");
        }
    }

    /**
     * Loads all saved password entries from the user's file, decrypts them, and displays them.
     */
    public void loadSavedPasswords() {
        flowpane.getChildren().clear();

        if (userDataFileName == null || userDataFileName.isEmpty()) {
            showAlert("Error", "Data File Missing", "Cannot find the data file for this user.");
            return;
        }
        if (encryptionKey == null) {
            showAlert("Error", "Session Error", "User session is invalid. Please log in again.");
            logout();
            return;
        }

        List<String> decryptedLines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(userDataFileName))) {
            String encryptedLine;
            while ((encryptedLine = reader.readLine()) != null) {
                if (!encryptedLine.trim().isEmpty()) {
                    try {
                        String decryptedData = CryptoUtils.decrypt(encryptedLine, encryptionKey);
                        decryptedLines.add(decryptedData);
                    } catch (Exception e) {
                        showAlert("Warning", "Data Corruption", "Could not decrypt one of the password entries.");
                    }
                }
            }
        } catch (IOException e) {
            showAlert("Error", "File Read Error", "Could not read the password data file.");
            return;
        }

        for (int i = 0; i < decryptedLines.size(); i++) {
            createPasswordBox(decryptedLines.get(i), i);
        }
    }

    /**
     * Creates a password box UI element and adds it to the flowpane.
     * 
     * @param decryptedData The decrypted password data.
     * @param index The index of the password entry.
     */
    private void createPasswordBox(String decryptedData, int index) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Box.fxml"));
            AnchorPane passwordBox = loader.load();
            BoxController controller = loader.getController();

            String[] fields = decryptedData.split(",", 5);
            String title = fields.length > 3 && !fields[3].trim().isEmpty() ? fields[3] : (fields.length > 0 && !fields[0].trim().isEmpty() ? fields[0] : "Untitled Entry");
            String t = "" + title.charAt(0);

            controller.setTitle(t);
            controller.setEntireTitle(title);
            controller.setPasswordData(decryptedData, index);

            passwordBox.setOnMouseClicked(event -> {
                if (event.getClickCount() == 1) {
                    startWidgetP(controller.getPasswordData(), controller.getLineIndex());
                }
            });

            flowpane.getChildren().add(passwordBox);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Adds a new password entry to the user's file.
     * 
     * @param plainTextData The plain text password data to add.
     */
    public void addNewPasswordEntry(String plainTextData) {
        if (encryptionKey == null || userDataFileName == null) {
            showAlert("Error", "Session Error", "Cannot save password. Invalid session.");
            return;
        }
        try {
            String encryptedData = CryptoUtils.encrypt(plainTextData, encryptionKey);
            try (FileWriter fw = new FileWriter(userDataFileName, true);
                 BufferedWriter bw = new BufferedWriter(fw);
                 PrintWriter out = new PrintWriter(bw)) {
                out.println(encryptedData);
            }
            loadSavedPasswords();
        } catch (Exception e) {
            showAlert("Error", "Save Failed", "Could not encrypt and save the new password entry.");
        }
    }

    /**
     * Updates an existing password entry in the user's file.
     * 
     * @param lineIndex The index of the password entry to update.
     * @param newPlainTextData The new plain text password data.
     */
    public void updatePasswordEntry(int lineIndex, String newPlainTextData) {
        if (encryptionKey == null || userDataFileName == null) {
            showAlert("Error", "Session Error", "Cannot update password. Invalid session.");
            return;
        }

        List<String> allEncryptedLines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(userDataFileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                allEncryptedLines.add(line);
            }
        } catch (IOException e) {
            showAlert("Error", "Update Failed", "Could not read the data file to update the entry.");
            return;
        }

        if (lineIndex < 0 || lineIndex >= allEncryptedLines.size()) {
            showAlert("Error", "Update Failed", "Invalid entry index provided for update.");
            return;
        }

        try {
            String newEncryptedData = CryptoUtils.encrypt(newPlainTextData, encryptionKey);
            allEncryptedLines.set(lineIndex, newEncryptedData);

            try (FileWriter fw = new FileWriter(userDataFileName, false);
                 BufferedWriter bw = new BufferedWriter(fw);
                 PrintWriter out = new PrintWriter(bw)) {
                for (String line : allEncryptedLines) {
                    out.println(line);
                }
            }
            loadSavedPasswords();
        } catch (Exception e) {
            showAlert("Error", "Update Failed", "Could not encrypt and save the updated password entry.");
        }
    }

    /**
     * Deletes a password entry from the user's file.
     * 
     * @param lineIndex The index of the password entry to delete.
     */
    public void deletePasswordEntry(int lineIndex) {
        if (userDataFileName == null) {
            showAlert("Error", "Session Error", "Cannot delete password. Invalid session.");
            return;
        }

        List<String> allEncryptedLines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(userDataFileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                allEncryptedLines.add(line);
            }
        } catch (IOException e) {
            showAlert("Error", "Delete Failed", "Could not read the data file to delete the entry.");
            return;
        }

        if (lineIndex < 0 || lineIndex >= allEncryptedLines.size()) {
            showAlert("Error", "Delete Failed", "Invalid entry index provided for deletion.");
            return;
        }

        allEncryptedLines.remove(lineIndex);

        try (FileWriter fw = new FileWriter(userDataFileName, false);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            for (String line : allEncryptedLines) {
                out.println(line);
            }
        } catch (IOException e) {
            showAlert("Error", "Delete Failed", "Could not save changes after deleting the entry.");
            return;
        }

        loadSavedPasswords();
    }

    /**
     * Displays an alert dialog with the specified title, header, and content.
     * 
     * @param title The title of the alert dialog.
     * @param header The header text of the alert dialog.
     * @param content The content text of the alert dialog.
     */
    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}