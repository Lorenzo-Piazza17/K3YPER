/*
 * Copyright (c) 2025 Lorenzo Piazza and Azan Khan
 * License: View only. Modification and redistribution prohibited.
 * Attribution to the authors is mandatory. See LICENSE.txt for details.
 * Contact: project.license.info@gmail.com
 */

package testlogin;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author lollo
 */
public class BoxController implements Initializable {

    @FXML
    private Label titleLabel;  // This will display the first letter of the link name

    @FXML
    private Label EntireTitleLabel;  // This will display the entire link name

    private String passwordData; // Store the full password data
    private int lineIndex; // Store the line index for editing

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    /**
     * Sets the title of the password box
     * @param title The text to display (link name)
     */
    public void setEntireTitle(String title) {
        if (EntireTitleLabel != null) {
            EntireTitleLabel.setText(title);
        }
    }

    /**
     * Sets the title of the password box
     * @param title The letter to display (link name)
     */
    public void setTitle(String title) {
        if (titleLabel != null) {
            titleLabel.setText(title);
        }
    }

    /**
     * Sets the password data and index for this box
     * @param data Full CSV data line
     * @param index Line index in file
     */
    public void setPasswordData(String data, int index) {
        this.passwordData = data;
        this.lineIndex = index;
    }

    /**
     * Get the password data stored in this box
     * @return The password data as CSV string
     */
    public String getPasswordData() {
        return this.passwordData;
    }

    /**
     * Get the line index for this password entry
     * @return The line index in the CSV file
     */
    public int getLineIndex() {
        return this.lineIndex;
    }
}
