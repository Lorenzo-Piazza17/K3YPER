/*
 * Copyright (c) 2025 Lorenzo Piazza and Azan Khan
 * License: View only. Modification and redistribution prohibited.
 * Attribution to the authors is mandatory. See LICENSE.txt for details.
 * Contact: project.license.info@gmail.com
 */

package testlogin;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;

/**
 * Controller class for the Login screen of the application.
 * Handles user authentication and navigation to other screens.
 */
public class LoginController {

    @FXML
    private TextField usernameField; // Input field for the username

    @FXML
    private PasswordField passwordField; // Input field for the password

    @FXML
    private Label errorLabel; // Label to display error messages

    /**
     * Handles the login button click event.
     * Authenticates the user and navigates to the Home screen if successful.
     *
     * @param event The ActionEvent triggered by the login button.
     */
    @FXML
    private void handleLoginButton(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        // Validate input fields
        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Username and password cannot be empty");
            return;
        }

        // Authenticate the user
        if (UserAuth.authenticateUser(username, password)) {
            try {
                // User authenticated, load the Home screen
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Home.fxml"));
                Parent homeRoot = loader.load();

                // Pass the username to the HomeController
                HomeController homeController = loader.getController();
                homeController.initData(username);

                // Set up the stage and scene
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(new Scene(homeRoot, 1350, 850));
                stage.setTitle("Home - " + username);

                // Center the window on the screen
                Rectangle2D screenBounds = Screen.getPrimary().getBounds();
                double screenWidth = screenBounds.getWidth();
                double screenHeight = screenBounds.getHeight();
                double stageWidth = stage.getWidth();
                double stageHeight = stage.getHeight();
                double x = (screenWidth - stageWidth) / 2;
                double y = (screenHeight - stageHeight) / 2;
                stage.setX(x);
                stage.setY(y);

                // Show the Home screen
                stage.show();

            } catch (IOException e) {
                e.printStackTrace();
                errorLabel.setText("Error loading home page");
            }
        } else {
            // Display error message for invalid credentials
            errorLabel.setText("Invalid username or password");
        }
    }

    /**
     * Handles the register link click event.
     * Navigates to the Registration screen.
     *
     * @param event The ActionEvent triggered by the register link.
     */
    @FXML
    private void handleRegisterLink(ActionEvent event) {
        try {
            // Load the Registration screen
            Parent registerRoot = FXMLLoader.load(getClass().getResource("Register.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(registerRoot, 600, 400));
            stage.setTitle("Register");

            // Show the Registration screen
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            errorLabel.setText("Error loading registration page");
        }
    }
}