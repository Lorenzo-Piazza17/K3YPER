/*
 * Copyright (c) 2025 Lorenzo Piazza and Azan Khan
 * License: View only. Modification and redistribution prohibited.
 * Attribution to the authors is mandatory. See LICENSE.txt for details.
 * Contact: project.license.info@gmail.com
 */

package testlogin;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Controller class for the Registration screen of the application.
 * Handles user registration and navigation back to the login screen.
 */
public class RegisterController {

    @FXML
    private TextField usernameField; // Input field for the username

    @FXML
    private PasswordField passwordField; // Input field for the password

    @FXML
    private PasswordField confirmPasswordField; // Input field for confirming the password

    @FXML
    private Label errorLabel; // Label to display error messages

    /**
     * Handles the register button click event.
     * Validates the input fields, registers the user, and navigates to the login screen if successful.
     *
     * @param event The ActionEvent triggered by the register button.
     */
    @FXML
    private void handleRegisterButton(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();

        // Validate inputs
        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            errorLabel.setText("All fields must be filled");
            return;
        }

        if (!password.equals(confirmPassword)) {
            errorLabel.setText("Passwords do not match");
            return;
        }

        // Check if username exists
        if (UserAuth.userExists(username)) {
            errorLabel.setText("Username already exists. Please choose another one.");
            return;
        }

        // Register user
        if (UserAuth.registerUser(username, password)) {
            try {
                // Registration successful, go to login page
                Parent loginRoot = FXMLLoader.load(getClass().getResource("Login.fxml"));
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(new Scene(loginRoot, 600, 400));
                stage.setTitle("Login");
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
                errorLabel.setText("Error loading login page");
            }
        } else {
            errorLabel.setText("Registration failed. Please try again.");
        }
    }

    /**
     * Handles the back-to-login link click event.
     * Navigates back to the login screen.
     *
     * @param event The ActionEvent triggered by the back-to-login link.
     */
    @FXML
    private void handleBackToLoginLink(ActionEvent event) {
        try {
            Parent loginRoot = FXMLLoader.load(getClass().getResource("Login.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(loginRoot, 600, 400));
            stage.setTitle("Login");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            errorLabel.setText("Error loading login page");
        }
    }
}