/*
 * Copyright (c) 2025 Lorenzo Piazza and Azan Khan
 * License: View only. Modification and redistribution prohibited.
 * Attribution to the authors is mandatory. See LICENSE.txt for details.
 * Contact: project.license.info@gmail.com
 */

package testlogin;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

/**
 * Utility class for cryptographic operations such as key derivation, encryption, and decryption.
 * This class uses AES/GCM for encryption and PBKDF2 for key derivation.
 */
public class CryptoUtils {

    // Constants for encryption and key derivation
    private static final String ENCRYPTION_ALGORITHM = "AES/GCM/NoPadding";
    private static final String KEY_DERIVATION_ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final int AES_KEY_SIZE = 256; // bits
    private static final int GCM_IV_LENGTH = 12; // bytes (96 bits) - Recommended for GCM
    private static final int GCM_TAG_LENGTH = 16; // bytes (128 bits) - Recommended for GCM
    private static final int PBKDF2_ITERATIONS = 65536; // Iteration count for PBKDF2
    private static final int SALT_LENGTH = 16; // bytes - Should match the salt length used for master password hashing

    /**
     * Derives an AES key from the master password and salt using PBKDF2.
     *
     * @param masterPassword The master password to derive the key from.
     * @param salt The salt to use for key derivation.
     * @return A SecretKey object representing the derived AES key.
     * @throws NoSuchAlgorithmException If the PBKDF2 algorithm is not available.
     * @throws InvalidKeySpecException If the key specification is invalid.
     */
    public static SecretKey deriveKey(String masterPassword, byte[] salt) throws NoSuchAlgorithmException, InvalidKeySpecException {
        SecretKeyFactory factory = SecretKeyFactory.getInstance(KEY_DERIVATION_ALGORITHM);
        KeySpec spec = new PBEKeySpec(masterPassword.toCharArray(), salt, PBKDF2_ITERATIONS, AES_KEY_SIZE);
        SecretKey tmp = factory.generateSecret(spec);
        return new SecretKeySpec(tmp.getEncoded(), "AES");
    }

    /**
     * Encrypts plain text data using AES/GCM.
     *
     * @param plainText The plain text to encrypt.
     * @param key The AES key to use for encryption.
     * @return A Base64 encoded string containing the IV and ciphertext.
     * @throws Exception If an error occurs during encryption.
     */
    public static String encrypt(String plainText, SecretKey key) throws Exception {
        byte[] iv = new byte[GCM_IV_LENGTH];
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv); // Generate a random IV

        Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGORITHM);
        GCMParameterSpec parameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, iv); // Specify IV length and tag length
        cipher.init(Cipher.ENCRYPT_MODE, key, parameterSpec);

        byte[] cipherText = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));

        // Prepend IV to the ciphertext for storage
        ByteBuffer byteBuffer = ByteBuffer.allocate(iv.length + cipherText.length);
        byteBuffer.put(iv);
        byteBuffer.put(cipherText);
        byte[] cipherMessage = byteBuffer.array();

        // Return Base64 encoded string (IV + Ciphertext)
        return Base64.getEncoder().encodeToString(cipherMessage);
    }

    /**
     * Decrypts AES/GCM encrypted data.
     *
     * @param encryptedData The Base64 encoded string containing the IV and ciphertext.
     * @param key The AES key to use for decryption.
     * @return The decrypted plain text.
     * @throws Exception If an error occurs during decryption.
     */
    public static String decrypt(String encryptedData, SecretKey key) throws Exception {
        byte[] cipherMessage = Base64.getDecoder().decode(encryptedData);

        // Extract IV from the beginning of the cipher message
        ByteBuffer byteBuffer = ByteBuffer.wrap(cipherMessage);
        byte[] iv = new byte[GCM_IV_LENGTH];
        byteBuffer.get(iv);
        byte[] cipherText = new byte[byteBuffer.remaining()];
        byteBuffer.get(cipherText);

        Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGORITHM);
        GCMParameterSpec parameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8, iv); // Use the extracted IV
        cipher.init(Cipher.DECRYPT_MODE, key, parameterSpec);

        byte[] plainTextBytes = cipher.doFinal(cipherText);

        return new String(plainTextBytes, StandardCharsets.UTF_8);
    }

    /**
     * Decodes a Base64 encoded salt string.
     *
     * @param base64Salt The Base64 encoded salt string.
     * @return A byte array representing the decoded salt, or null if decoding fails.
     */
    public static byte[] decodeSalt(String base64Salt) {
        if (base64Salt == null) {
            System.err.println("Error: Salt string is null.");
            return null; // Or throw an exception
        }
        try {
            return Base64.getDecoder().decode(base64Salt);
        } catch (IllegalArgumentException e) {
            System.err.println("Error decoding Base64 salt: " + e.getMessage());
            // Log the problematic salt string for debugging
            System.err.println("Problematic salt string: '" + base64Salt + "'");
            return null; // Or throw an exception
        }
    }
}
